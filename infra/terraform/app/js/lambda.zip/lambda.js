module.exports.handler = async (event) => {
    console.log('Event: ', event)

    return "Success!"
}